package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService{
@Autowired
	EmployeeRepository er1;

@Override
public Employee saveEmployee(Employee employee) {
	return er1.save(employee);
}

@Override
public List<Employee> fetchEmployeeList() {
	return er1.findAll();
}

@Override
public Employee fetchEmployeeById(Long employeeId) {
	return er1.findById(employeeId).get();
}
@Override
public void deleteEmployeeById(Long employeeId) {
	er1.deleteById(employeeId);
}
@Override
public Employee updateEmployee(Long employeeId, Employee employee) {
	 Employee empDB = er1.findById(employeeId).get();

     if(Objects.nonNull(employee.getEmployeeName()) &&
     !"".equalsIgnoreCase(employee.getEmployeeName())) {
         empDB.setEmployeeName(employee.getEmployeeName());
     }

     if(Objects.nonNull(employee.getEmployeeSalary())){
         empDB.setEmployeeSalary(employee.getEmployeeSalary());
     }

     if(Objects.nonNull(employee.getEmployeeAddress()) &&
             !"".equalsIgnoreCase(employee.getEmployeeAddress())) {
         empDB.setEmployeeAddress(employee.getEmployeeAddress());
     }
     if(Objects.nonNull(employee.getEmployeeDesignation()) &&
             !"".equalsIgnoreCase(employee.getEmployeeDesignation())) {
         empDB.setEmployeeDesignation(employee.getEmployeeDesignation());
     }
         return er1.save(empDB);
}

    	
}

